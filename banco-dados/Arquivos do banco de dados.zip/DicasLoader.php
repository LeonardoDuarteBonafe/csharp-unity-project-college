<?php
	$servername = "localhost";
	$username = "id7533976_leonardo";
	$password = "123qwe";
	$dbName = "id7533976_testedb";
	
	//make connection
	$conn = new mysqli($servername, $username, $password, $dbName);
	//check connection 
	
	if(!$conn){
		die("Connection Failed.". mysqli_connect_error());
	}
	
	$sql = "SELECT * FROM dicas";
	$result = mysqli_query($conn, $sql);
	
	/*$sql = "SELECT * FROM items";
	$result = mysqli_query($conn, $sql);
    if(mysqli_num_rows($result)>0){
    	while($row = mysqli_fetch_assoc($result)){
    		echo("ID:".$row['ID'] . "|Name:".$row['Name']. "|Type:".$row['Type']. "|Cost:".$row['Cost'] . ";"); 	
    	}
	}*/
	
    if(mysqli_num_rows($result)>0){
    	while($row = mysqli_fetch_assoc($result)){
    		echo("index:".$row['index']. "|Dica1:".$row['dica1']. "|Dica2:".$row['dica2']. "|Dica3:".$row['dica3']. "|Dica4:".$row['dica4']. "|Dica5:".$row['dica5'] . ";"); 	
    	}
	}
?>