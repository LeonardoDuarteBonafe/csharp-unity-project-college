<?php
$dica1 = filter_input(INPUT_POST, 'dica1');
$dica2 = filter_input(INPUT_POST, 'dica2');
$dica3 = filter_input(INPUT_POST, 'dica3');
$dica4 = filter_input(INPUT_POST, 'dica4');
$dica5 = filter_input(INPUT_POST, 'dica5');

if(!empty($dica1) && !empty($dica2) && !empty($dica3) && !empty($dica4) && !empty($dica5)){
            $servername = "localhost";
    	    $server_username = "id7533976_leonardo";
    	    $server_password = "123qwe";
    	    $dbName = "id7533976_testedb";
    
            // Create connection
            $conn = new mysqli ($servername, $server_username, $server_password, $dbName);
            
            if (mysqli_connect_error()){
                die("Connect Error (". mysqli_connect_errno() .") ". mysqli_connect_error());
            }
            else{
                $sql = "INSERT INTO dicas (dica1, dica2, dica3, dica4, dica5)
                VALUES ('$dica1','$dica2','$dica3','$dica4','$dica5')";
                if ($conn->query($sql)){
                    echo "Dicas inseridas com sucesso";
                }
                else{
                    echo "Error: ". $sql ."". $conn->error;
                }
            $conn->close();
            }
}
else{
    echo "Dicas não podem ficar vazias";
    die();
}
?>